is_leap_year = False
input_year = int(input())

if (input_year % 4) == 0 and (input_year % 100!=0) or (input_year % 400) == 0:
        result = "{0} - leap year".format(input_year)
        print(result)
else:
    result = "{0} - not a leap year".format(input_year)
    print(result) 